import { Injectable } from '@angular/core';
@Injectable()
export class BackendService {
  private nombres: String [] = [
    "SERVICIO: Primer profesor", 
    "SERVICIO: Segundo profesor", 
    "SERVICIO: Tercer profesor"
    ];
    getProfesor (id){
      return this.nombres[id];
    }
  constructor() { }
    
}
