import { Component, OnInit } from '@angular/core';
import { ProfesoresComponent } from  "../profesores/profesores.component";
import { BackendService } from '../backend.service';
@Component({
  selector: 'app-cursos',
  templateUrl: './cursos.component.html',
  styleUrls: ['./cursos.component.css']
})
export class CursosComponent implements OnInit {
  private title = "Lista de cursos";

  //La declaración es igual:
  private misProfesores : ProfesoresComponent;
  private servicioProfesores : BackendService;
  private cursos = [
    "Entornos de desarrollo",
    "Sistemas informáticos",
    "Lenguajes de marcas"
  ];
  getTitle (){
    return (this.title);
  }
  getCursos (){
    return (this.cursos);
  }
  
  constructor(servicio: BackendService) { 
    this.servicioProfesores = servicio;
    //this.misProfesores = new ProfesoresComponent ();  
  }
  ngOnInit() {
  }
}