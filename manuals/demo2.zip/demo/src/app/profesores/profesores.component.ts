import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-profesores',
  templateUrl: './profesores.component.html',
  styleUrls: ['./profesores.component.css']
})
export class ProfesoresComponent implements OnInit {
  private nombres: String [] = ["Primer profesor", 
    "Segundo profesor", 
    "Tercer profesor"];
  constructor() { 
  }
  getNombre (id: number){
    return this.nombres [id];
  }
  pruebaProfes (){
    return "ProbandoProfes";
  }
  ngOnInit() {
  }

}