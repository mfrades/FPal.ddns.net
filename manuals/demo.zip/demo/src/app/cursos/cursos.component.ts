import { Component, OnInit } from '@angular/core';
import { ProfesoresComponent } from  "../profesores/profesores.component";
@Component({
  selector: 'app-cursos',
  templateUrl: './cursos.component.html',
  styleUrls: ['./cursos.component.css']
})
export class CursosComponent implements OnInit {
  private title = "Lista de cursos";
  private misProfesores : ProfesoresComponent;

  private cursos = [
    "Entornos de desarrollo",
    "Sistemas informáticos",
    "Lenguajes de marcas"
  ];
  getTitle (){
    return (this.title);
  }
  getCursos (){
    return (this.cursos);
  }
  constructor() { 
    this.misProfesores = new ProfesoresComponent ();  
  }
  ngOnInit() {
  }
}